This folder contains:
1. The PCB Gerber files. Send these to a PCB manufacturer. We recommend:
	https://www.elecrow.com/5pcs-2-layer-pcb.html
2. The SMT_reference. Use this to populate the PCBs.

