This folder contains:
1. The box dimensions from http://www.enclosuresandcasesinc.com/ for split body 2506-2.9”
	1. They will not anodize or use the attached silkscreen for small orders.
	2. If you pay an extra 100$, they can set up the anodization and the silkscreen. if this is something you want, you can send them these files.
		Enclosure_silkscreen_bottom.pdf
		Enclosure_silkscreen_top.pdf	

2. If you want to laser cut the acrylic endplates:
	 1. Send EndPlates_for_laser_cutting.dxf.zip to https://www.elecrow.com/5pcs-acrylic-laser-cutting-service.html
		- Thickness: 2.5mm
		- Color: your choice
		- Dimensions: 10 x 15 cm
	2. Note, this will give you x10 endplates.
			
